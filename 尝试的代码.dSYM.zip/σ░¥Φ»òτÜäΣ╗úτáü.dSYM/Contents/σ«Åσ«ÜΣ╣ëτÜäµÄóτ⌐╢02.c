#include<stdio.h>
#define CON1(a,b) a##1##b
#define CON2(a,b) a##b##00//'##'表示连接非变量和变量
int main(){
    printf("%f\n",CON1(8.5,2));
    printf("%d\n",CON2(12,34));
    return 0;
}