#include<stdio.h>
int fun1(int a,int b){
    int temp,i,result;
    if (a>b)
    {
        temp = a;
        a = b;
        b = temp;
    }
    for ( i = 1; i <=a; i++)
    {
        if (a%i==0&&b%i==0)
        {
            result = i;
            
        }
        
    }
    return result;

}
int main(){
    int m , n;
    scanf("%d %d",&m,&n);
    printf("这两个数的最大公数是%d\n",fun1(m,n));
    return 0;
    
}
