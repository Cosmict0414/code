#include<stdio.h>
int main(void){
    char a=0;
    while (a!='\n')//遇到回车键时停止循环
 {a = getchar();//单个字符进行读取
    if (a == '4' || a == '8')
 {
     continue;
 }
     putchar(a);
 }
    return 0;
    
}