#include<stdio.h>
int main(void)
{    int m=5 ;
     float n= 2.5;
     double a=18.5,b=6.4;
    printf("%d\n",(int)a%(int)b);
    printf("(float)(m/2)=%f\n",(float)(m/2));//之前以int输入m，先计算括号内的结果为5/2=2,并以单精度输出结果
    printf("(float)m/2=%f\n",(float)m/2);//""内的内容为直接输出的格式  float修饰m覆盖int的效果，结果直接运算
    printf("%f\n",n);                    //“”外的，后的内容对应输出内容中的%_


}