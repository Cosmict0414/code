#include<stdio.h>
int count = 0;
int movement(int n , char a , char b )
{
    printf("将%d号环从 %c 移到 %c \n", n , a , b );
    count++;
    return 0 ;
}

int Hanoita(int n, char  a,char b,char c){
    if (n<=1)
    {
        movement(1,a,b);
    }
    else{
        Hanoita(n-1 , a , c , b );
        movement(n , a , b);
        Hanoita(n-1 , c , b ,a);
    }
    return 0;
}
int main(){
    int n;
    char a = 'a';
    char b = 'b';
    char c = 'c';
    printf("请输入汉诺塔层数");
    scanf("%d",&n);
    Hanoita(n , a , b , c );
    printf("一共经过%d次完成\n",count);
    return 0;
}