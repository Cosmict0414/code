#include<iostream>
using namespace std;
int main(){
    FILE *fp = fopen("input.txt","r");
    int a,b,c,d;
    fscanf(fp,"%d %d\n %d %d",&a,&b,&c,&d);//fp后面的，很重要
    fclose(fp);
    printf("%d %d %d %d\n",(int)a,(int)b,(int)c,(int)d);

    return 0;
}