#include<iostream>
int main(){
    int goal=0;
    int a,b,c;
     scanf("%d %d %d\n",&a,&b,&c);
     if (a==5){goal+=2;}
     else if(a==4){goal+=1;}
     else if(a==2){goal-=1;}//计算发色加减分
     if (b==0) {goal=+1;}else{goal-=1;}//计算年龄加减分
     if((c*10+100)<180){goal+=1;}else if((c*10+100)>190){goal-=1;}//计算身高得分
     printf("该组得分为%d",goal);
     return 0;
}