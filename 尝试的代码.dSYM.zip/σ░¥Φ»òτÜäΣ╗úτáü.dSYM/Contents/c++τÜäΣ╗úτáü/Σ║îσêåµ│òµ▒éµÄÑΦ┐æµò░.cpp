#include<iostream>
int main(){
    int a[10];
    int i , l=0 , r=9, b , mid=0;
    FILE *fp = fopen("input_01.txt","r");
    for ( i = 0; i < 10; i++)
    {
        fscanf(fp,"%d",&a[i]);
    }
    for ( i = 0; i < 10; i++)
    {
        printf("  %d",a[i]);
    }
    
    printf("请输入你选中的数字");
    scanf("%d",&b); 
    while (l<=r)
    {
        mid=(l+r)/2;
        if (a[mid]<b)
        {
            l=mid-1;
        }else{
            r=mid+1;
        }       
    }
    printf("%d",a[mid]);
    printf("你输入的数字与%d最接近\n",a[mid]);
    return 0;
}