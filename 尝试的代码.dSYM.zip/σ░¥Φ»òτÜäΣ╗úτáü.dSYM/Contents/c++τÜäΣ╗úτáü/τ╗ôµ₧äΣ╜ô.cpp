#include<iostream>
#include<string>
using namespace std;

class Student{
    string Name;
    int Number;
    double score[3];
    double FinalScore;
}Stu1;
void GetstudentData(Student &Stu){
    for (int i = 0; i < 3; i++)
    {
        cin>>Stu.score[i];
        return;
    }
void DisplayStudentData(Student Stu){
    cout<<Stu.Name<<endl;
    cout<<Stu.Name
}
    

}

int main(){
    Student Stu1;
    GetstudentData(Stu1);
    for(int i=0;i<10000);
    cin>>Stu1,Name>>Stu1,Number;
    int Number;
    double score[3];
    cin>>Name>>Number;
    for(int i=0;i<3;i++)
        cin>>score[i];
    cout<<Name<<endl;
    cout<<Number<<endl;
    for(int i=0;i<3;i++)
        cout<<score[i]<<endl;
    return 0;
}