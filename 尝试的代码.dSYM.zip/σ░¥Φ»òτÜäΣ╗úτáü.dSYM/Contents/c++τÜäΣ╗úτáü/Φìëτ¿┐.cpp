#include<iostream>
#include<math.h>
using namespace std;
int main(){
    int result=0,mid=0,l=0,r=9,b=50;
    int a[10]={1,11,21,32,43,52,64,73,85,95};
    printf("请输入你选中的数字");
    while (l<=r)
    {
        mid=(l+r)/2;
        if (a[mid]<b)
        {
            l=mid-1;
        }else if(a[mid]>b)
        {
            r=mid+1;
        }else{
            mid=mid;
        }
    }
    printf("你输入的数字与%d最接近\n",a[mid]);
    return 0;

}
