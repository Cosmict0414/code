#include<iostream>


namespace space1{
    int ID = 1;
    void display(){
    std::cout<<"I am in space1 "<<std::endl;//“std::”表示从std中引用cout和cin这两个函数
    }
    
}
namespace space2{
    void display(){
        std::cout<<"I am in space2"<<std::endl;
    }
    void number(int a){
        std::cout<<a<<std::endl;
    }
}

int main(){
    space1::display();//从space1当中调用display函数
    space2::number(space1::ID);//从space2中调用number函数，且number的形参由space2中的ID赋值
}