#include<iostream>
#include<string>
#include<cmath>
using namespace std;
#define PI 3.1415926
 int main()
 {
    bool B;
    cout<<sizeof(B)<<endl;
    int INT=4;
    cout<<sizeof(INT)<<endl;
    long long int I;
    cout<<sizeof(I)<<endl;
    char a;
    cout<<sizeof(a)<<endl;
    string b;
    cout<<sizeof(b)<<endl;
    const int c=100;
    cout<<(c)<<endl;
    const bool d =1;
    cout<<(d)<<endl; 
    cout<<(PI)<<endl;

    return 0;

 }
