#include<iostream>
#include<string>
using namespace std;

class Student{
    public:
        string Name;
        int Number;
        void DisplayScore(){
                cout<<FinalScore<<endl;
                for (int i = 0; i < 3; i++)
                {
                    cout<<"->"<<Score[i]<<endl;
                }
                Student(){
                    Name = "Nameless";
                    Number = 0;
                    FinalScore = Score[0]=Score[1]=Score[2]=60;
                }

        }   
    private:
        double Score[3];
        double FinalScore;
}Stu1;

int main(){

    return 0;
}