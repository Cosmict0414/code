#include<iostream>
int score(int n){
    int goal=0;
    int a,b,c;
     a=(n-(n%100))/100;
     b=(n-a*100-((b-a*100)%10))/10;
     c=n-a*100-b*10;
     if (a==5){goal+=2;}
     else if(a==4){goal+=1;}
     else if(a==2){goal-=1;}//计算发色加减分
     if (b==0) {goal=+1;}else{goal-=1;}//计算年龄加减分
     if((c*10+100)<180){goal+=1;}else if((c*10+100)>190){goal-=1;}//计算身高得分
     return goal;
}//进行计算得分的公式组
int main(){
    int i,j,temp0,temp1;
    int num[9];//存储计算数据
    int team[9];//存储组号
    FILE *fp = fopen("details.txt","r");
    fscanf(fp,"%d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d",&team[1],&num[1],&team[2],&num[2],&team[3],&num[3],&team[4],&num[4],&team[5],&num[5],&team[6],&num[6],&team[7],&num[7],&team[8],&num[8],&team[0],&num[0]);
    //没有什么是可以阻挡我的
    for ( i = 0; i < 9; i++)
    {
        num[i]=score(num[i]);//将计算好的得分重新赋给num数组
    }
    
    for ( i = 0; i < 9-1; i++)
    {
        for ( j = 0; j < 9-1-i; j++)
        {
            if (num[j]>num[j+1])
            {
                temp0=num[j];
                num[j]=num[j+1];
                num[j+1]=temp0;
                temp1=team[j];
                team[j]=team[j+1];
                team[j+1]=temp1;
            }
            
        }
        
    }//比大小的同时更改组号
    for ( i = 8; i >=0; i--)
    {
        printf("%d %d\n",team[i],num[i]);
    }//输出结果
    return 0;   

}