
#include <iostream>
#include <cmath>
using namespace std;
const  double ipsl = 0.001; 
const  double e =  2.718;
double sigmoid_func(double m){
    double result;
    result = 1/(1+pow(e,-m));
    printf("%lf\t",result);
    return result;
}
int main(){
    double  a ;
    double l=-1000000000,r= 1000000000,mid;
    printf("请输入数字");
    scanf("%lf",&a);
    while ((r-l)>=ipsl)
    {   mid=(l+r)/2;
        if (sigmoid_func(mid)<a)
        {
            l=mid;
        }else if (sigmoid_func(mid)>a)
        {
            r=mid;      
        }else{
            break;
        }
    }
    printf("%.3lf\n",mid);
    return 0;
}