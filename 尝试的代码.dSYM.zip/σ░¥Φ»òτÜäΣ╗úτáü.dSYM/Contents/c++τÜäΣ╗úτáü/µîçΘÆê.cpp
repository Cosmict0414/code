#include<iostream>
using namespace std;

int main(){
    int a,b;
    int *p = &a;//*p必须指向的是变量的地址
    scanf("%d",p);
    p = &b;

}//&p表示引用意味将一个变量用两个名字表示