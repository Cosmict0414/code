#include<iostream>
using namespace std;
int main()
{
cout<<"Hello World"<<endl;
return 0;//告知程序结束的状态
}

