#include<stdio.h>
#include<unistd.h>//使sleep生效
int main(void)
{
    int a=1099,b=233,c=389;
    double n=882.847234,m;
    printf("%9d%-9d %d\n",a,b,c);//-9意味着占后9个位置;9意味着占前九个位置
    printf("n=%-9.2lf n=%.5lf\n",n,n);//".x"意味着留几位小数
    sleep(2);//暂停设定秒数再继续执行
    printf("n=%#.0f\n",n);//对于小数强迫输出小数点
  }