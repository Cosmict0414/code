#include<stdio.h>
int prime(int n){
    int i,a=1;
    if (n<=0)
    {
        return -1;
    }
    else{
        for ( i = 2; i < n; i++)
        {
            if (n%i==0)
            {
                a=0;
                break;
            }

        }
            
        }   return a;
        
    }
int main(){
    int b,c;
    scanf("%d",&b);
    c=prime(b);
    if (c<0)
    {
        printf("This is an illegle number");
    }else if(c==0){
        printf("This is a prime number");;
    }else{
        printf("This isn't a prime number" );
    }
    return 0;

}
