#include<stdio.h>
int main(void)
{  
     char a[1000];
     long long int c;
     printf("请输入两遍数字\n");
     scanf("%s %lld",a,&c);
    if (a[0]<'0'||'9'<a[0])
     {printf("该输入数字不符合标准\n"); 
     }
    else if ((float)c/2==(int)c/2)
     { 
     printf("这个数除以2是%f,所以是偶数\n",(double)c/2);
     }else{ 
       printf("这个数除以2是%f,所以是奇数\n",(double)c/2);
     }
    return 0;

}/*花括号的缩进，逻辑错误
  printf和scanf的运用与具体的含义*/
 
