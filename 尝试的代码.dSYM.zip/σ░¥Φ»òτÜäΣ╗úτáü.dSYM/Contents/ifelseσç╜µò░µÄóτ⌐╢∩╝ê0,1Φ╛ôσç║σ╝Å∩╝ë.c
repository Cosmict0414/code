#include<stdio.h>
int main(void)
{
    int a=1,b=2,c=3;
    float x=3e+5,y=0.85;
    int result_1= 'a'+5>c,
        result_2=x-5.25<=x+y;
    printf("%d,%d\n",result_1,-a-2*a>=b+1);
    printf("%d,%d\n",1<b<5,result_2);
    printf("%d,%d\n",a+b+c==-2*b,c==b==a+5);//"=="为判断语句，输出结果只有1,2
    return 0;

}