#include<stdio.h>
int main(void)
{   int a,money,change;
    printf("你要多少钱的\t");
    scanf("%d",&a);
    printf("你给多少钱\t");
    scanf("%d",&money);
    change =money-a;
    printf("找您%d\n",change);
    return 0;

}