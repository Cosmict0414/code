#include<stdio.h>
int main()
{
    int a=100;
    int b=0b101010;//二进制输入
    int c=0x1ffff;//十六进制输入
    int d=789003;
    printf("a=%d\n,b=%d\n,c=%o\n,d=%x\n",a,b,c,d);//a，b均为十进制输出，
    //c为八进制输出，d为十六进制输出

}