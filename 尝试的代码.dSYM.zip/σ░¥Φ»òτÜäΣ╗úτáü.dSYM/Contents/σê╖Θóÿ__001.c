#include<stdio.h>

int main(void)
{
    int n=4, m=5,n1,n2,a=4;
    n1= (n<m);
    n2=n1==5;
    printf("n1=%-9d n2=%d\n",n1,n2);
      

}