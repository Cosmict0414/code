#include<stdio.h>
#include<unistd.h>
int main(void)
{
    char  a;
    a = getchar();//是printf("%c")的简写
    printf(" a:%c\n",a);

    sleep(5);//在输出a后便开始数秒

    char sentence[30],end[30];//标明字符串的长度
    scanf("%s %s",sentence,end);//记得要有几个输出就有几个格式表达符号
    /*在输入字符串时“ ”表示终止之后的内容赋给下一个量*/
    printf(" sentence:%s\n end:%s\n",sentence,end);

    printf("我爱");
    fflush(stdout);//表示清空缓行区的数据，可以不受到之后sleep函数的影响 
    sleep(5);//sleep上下的两个输出均在行缓行区中；
    printf("ZH\n");

    int c;
    printf("我爱");
    while((c=getchar())!='\n'&&c !=EOF);//效果与"fflush"相同(再MAC上无用)
    sleep(5);//sleep上下的两个输出均在行缓行区中；
    printf("ZH\n");



    printf("我爱");
    scanf("%*c");//效果与"fflush"相同
    sleep(5);//sleep上下的两个输出均在行缓行区中；
    printf("ZH\n");


}


