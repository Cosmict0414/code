#include<stdio.h>
#include<stdlib.h>
#include<time.h>
int main (void){
    srand((unsigned int)time(NULL));
    int number = 0;
    number = rand()%100+1;//使数字在下一次运行的时候重新随机取
    int count,a;
    for (a=0;a!=number;)
    {   printf("请输入你猜的数字");
        scanf("%d",&a);
        if (a<number)
        {
        printf("你猜猜的数小了\n");
        }else if(a>number){
            printf("你猜的数大了\n");
        }
        count++;
    }
    printf("恭喜你，你用了%d次猜对了\n",count);
    return 0;
    
}