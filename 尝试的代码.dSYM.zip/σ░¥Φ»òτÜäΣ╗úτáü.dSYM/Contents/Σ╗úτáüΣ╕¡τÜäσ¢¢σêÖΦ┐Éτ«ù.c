#include<stdio.h>
int main(void)
{
    int a=1,b=1,c =2;
    a+=1;
    printf("a=%d\n",a);
    printf("b=%d\n",b--);
    printf("b=%d\n",b);

}