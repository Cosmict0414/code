#include<stdio.h>
int main(void)
{
    int x=178,b0,b1,b2,sum;
    b0 =x/100;
    b1 =(x-100)/10;
    b2 =x%10;
    sum =b0+b1+b2;
    printf("b0=%d\t,b1=%d\t,b2=%d\n,sum=%d\n",b0,b1,b2,sum);

}