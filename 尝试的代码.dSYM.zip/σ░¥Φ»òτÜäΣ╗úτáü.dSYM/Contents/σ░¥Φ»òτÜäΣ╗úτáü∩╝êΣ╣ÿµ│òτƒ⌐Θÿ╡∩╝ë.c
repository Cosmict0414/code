#include<stdio.h>
int main(void){
     int a,b;
     a = 1;
     while ((1))
     {b = 1;//使内循环的b重新等于1，再次开始循环
        while (1)
        {
            printf("%-4d",a*b);//使输入的数以4个字符空开
            b++;
            if (b>7) break;//输入的结果以行的形式呈现
        }
        printf("\n");//使光标跳入下一行
        a++;
        if (a>7) break;//break用来结束所有循环
              
     }
     
}