#include<stdio.h>
#include<stdlib.h>
#define NUM1 10
#define NUM2 20
int main(){
    #if (defined NUM1 && defined NUM2)
    printf("NUM1: %d,NU2: &%d\n",NUM1,NUM2);
    #else
    printf("Error\n");
    #endif
    return 0;
       //‘#ifdef’和'#ifndef'后都只能跟随宏名表示如果该宏名已被定义则执行代码
}