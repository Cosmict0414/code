#include<stdio.h>
int main(void)
{
    int a = 1,b = 1;
    while(a<=9&&b<=9)
    {   a=1;
        while (a<=b)
        {
            printf("%d*%d=%d\t",a,b,a*b);
            a++;
        }
        printf("\n");
        b++;
    }
    

}