#include<stdio.h>
int main(void)
{
    char c;
    printf("Input a character:\n");
    c=getchar();
    if(c<32)//上面是char输入，所以32要通过ASCII码进行转换 
            printf("This is a contraol character\n");
    else if (c>='0'&&c<='9')
            printf("This is a digit\n");
    else if (c>='A'&&c<='Z')
            printf("This is a captical letter\n");
   else if (c>='a'&&c<='z')
            printf("This is a small letter\n");
    else 
            printf("This is an other character\n");/*如果是多个if else 嵌套从上往下进行判定，
                                                   一旦判定成功则直接跳过其他语句块*/
      
}