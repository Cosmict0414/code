#include <stdio.h>
#include <stdlib.h>

int main() {
    printf("Date : %s\n", __DATE__);
    printf("Time : %s\n", __TIME__);
    printf("File : %s\n", __FILE__);
    printf("Line : %d\n", __LINE__);
    // __LINE__：表示当前源代码的行号；
    // __FILE__：表示当前源文件的名称；
    // __DATE__：表示当前的编译日期；
    // __TIME__：表示当前的编译时间；
    // __STDC__：当要求程序严格遵循ANSI C标准时该标识被赋值为1；
    // __cplusplus：当编写C++程序时该标识符被定义。
    system("pause");
    return 0;
}