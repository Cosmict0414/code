#include <stdio.h>
int main(){
    #if _WIN32//判断条件为“整型常量表达式”
    system("color 0c");
    printf("hrrp://c.biancheng.net\n");//若宏_WIN32的值为真则执行第4,5行的代码
    #elif __llinux__
    printf("\033[22;31mhrrp://c.biancheng.net\n\033[22;30m");//若__linux__的值为真则执行第7行的代码
    #else
    printf("hrrp://c.bianxheng.net\n");//如果所有的宏都为假则执行第9行代码
    #endif
    return 0;
    //除此之外‘#ifdef’和'ifndef'后都只能跟随宏名表示
}