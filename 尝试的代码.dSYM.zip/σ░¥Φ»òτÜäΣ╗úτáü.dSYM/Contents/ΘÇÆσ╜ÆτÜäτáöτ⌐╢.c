#include<stdio.h>
#include<string.h>
char *reverse(char *str){
    int len = strlen(str);
    char temp;
    if (len>1)
    {
        temp = str[0];
        str[0]=str[len-1];
        str[len-1]='\0';
        reverse(str + 1);
        str[len - 1] = temp;
    }
    
    return str;
}
int main(){
    char str[20] = "123456789";
    printf("%s\n",
    reverse(str));
    return 0;
}