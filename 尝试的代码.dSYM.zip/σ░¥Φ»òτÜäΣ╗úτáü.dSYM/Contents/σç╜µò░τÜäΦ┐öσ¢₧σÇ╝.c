#include<stdio.h>
int sum(int begin, int end){
    int i , sum=0;//如果sum没有定值那么就会是一窜乱序数字
    for ( i = begin; i <=end; i++)
    {
        sum+=i;
    }
    return sum;
}
int main(){
    int a =sum(1,100);
    printf("the sum is %d\n",a);
    return 0;
}