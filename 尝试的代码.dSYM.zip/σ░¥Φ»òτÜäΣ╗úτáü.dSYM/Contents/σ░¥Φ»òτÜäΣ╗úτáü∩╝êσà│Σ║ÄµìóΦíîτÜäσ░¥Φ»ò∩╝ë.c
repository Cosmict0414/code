#include<stdio.h>
int main()
{   char c='@';
    printf("n=%d\t,c=%d\n,money=%d\n",100,50,60);
    printf(
        "哈哈哈哈哈哈哈哈或。\n"
        "我是哦六班的nbplus.\n"
        );
    printf("abc\"123");
    return 0;
}

