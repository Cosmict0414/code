#include<stdio.h>
int main(void)
{
    int age;
    printf("请输入您的年龄：\n");
    scanf("%d",&age);
    if (age>=18)
    {
        printf("恭喜您，可以使用本软件\n");
    }
    else
    {
        printf("很遗憾，您的年龄未达到标准\n");
    }
    return 0;
}
