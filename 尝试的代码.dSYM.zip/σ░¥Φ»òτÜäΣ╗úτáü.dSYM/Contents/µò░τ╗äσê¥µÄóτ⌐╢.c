#include<stdio.h>
int main(void){
    int i,j,sum;
    int s[3];
    int a[5][3];
    for ( j = 0; j <=2; j++)
    {
        for ( i = 0; i <=4; i++)
        {
            scanf("%d",&a[i][j]);//从列开始输入
            s[j]=s[j]+a[i][j];
            sum+=a[i][j];
        }

    }
    printf("数学平均分%d,物理平均数%d,化学平均数%d\n",s[0]/5,s[1]/5,s[2]/5);
    printf("三科平均成绩是%d\n",sum/5);
    return 0;
    
}