#include<stdio.h>
int main(void)
{
    double a = 0.01,b = 0.02,c = 0.05;
    int x,y,z;
    int cout = 0;
    for (x=0;x<=100;++x)
        {
        for(y=0;y<=50;++y)
           {
            for(z=0;z<=20;++z)
                {
                if (x*a+y*b+z*c==1)
                    {
                    printf("1分钱有%d个,2分钱有%d个,5分钱有%d个\n",x,y,z);
                    cout++;
                    }
                }
            }
        }
    printf("一共有%d种组合方式\n",cout);
    return 0;
   
}