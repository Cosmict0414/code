#include<stdio.h>
int n;
int com(int a[n],int n){
    int i,j,tem,sum;
    for ( i = 0; i < n-1 ; i++)
    {
        for ( j = 0; j < n-1-i; j++)
        {
            if (a[j]>a[j+1])
            {
                tem=a[j+1];
                a[j+1]=a[j];
                a[j]=tem;
            }
            
        }
    }
     sum=a[n-1]-a[0];
     return sum;
}
int main(){
    int sum,i;
    int a[n];
    printf("请输入你要求的数字个数\n");
    scanf("%d",&n);
    printf("请输入这些数");
    for (i = 0; i < n; i++)
    {
        scanf("%d",&a[i]);
    }
    sum=com(a[n],n);
    printf("这组数字的极差是%d\n",sum);
    return 0;
    
}