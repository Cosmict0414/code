#include<stdio.h>
int mult(int n);
long sum(int m,int n);
int main(){
    int m , n;
    printf("你要计算从多少到多少的阶乘之和\n");
    scanf("%d %d",&m,&n);
    // printf("%d",mult(5));
    printf("阶乘之和等于%ld\n",sum(m,n));
    return 0;
}
int mult(int n){
    int i,result=1;
    for ( i = 1; i <=n; i++)
    {
        result*=i;
    }return result;
}
long sum(int m,int n){
    int i,result = 0;
    for ( i = m; i <=n; i++)
    {
        result+=mult(i);
    }
    return result;
    
}

