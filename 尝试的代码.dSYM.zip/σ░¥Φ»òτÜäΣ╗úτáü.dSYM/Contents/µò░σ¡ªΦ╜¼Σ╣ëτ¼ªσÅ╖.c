#include<stdio.h>
int main(void){
    char a ='\61';
    char b ='\x31';
    char *c = "\x31\x32\x33";/*通过转义符号输出字符串*/
    printf("%s\n", c);
    puts("\x68\164\164\x70\n");

}
