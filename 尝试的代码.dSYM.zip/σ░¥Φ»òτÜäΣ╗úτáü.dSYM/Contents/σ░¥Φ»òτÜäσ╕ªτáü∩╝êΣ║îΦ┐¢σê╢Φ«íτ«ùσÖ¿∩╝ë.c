#include<stdio.h>
int main(void){
     int a,b;
     printf("请输入一个数字");
     scanf("%d",&a);
     if (a<2)
     {
       printf("1");
     }
     else
     {
     do
     {
         if (a%2==1)
         {
         printf("1");
         a=a/2;
         }
         else
         {
          printf("0");
          a=a/2;
         }
        
         } while (a>0);
         
     }
     return 0;
     
}//结果要通过从右往左看