#include<stdio.h>
int func1(){
    printf("你好");
    return 0;
}
int func2(){
    func1();
    printf("世界\n");//无法在函数中定义函数，要用嵌套的函数只能分开定义后再在一个函数中表达。
    return  0;
}
int main(){
    func2();
    return 0;
}