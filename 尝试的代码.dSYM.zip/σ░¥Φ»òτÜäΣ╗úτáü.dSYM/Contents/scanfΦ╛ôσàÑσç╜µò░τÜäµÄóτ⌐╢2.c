#include<stdio.h>
#include<unistd.h>
int  main(void)
{
    int a=1,b=2;
    scanf("%d",&a);
    scanf("%d",&b);
    printf("a=%d\tb=%d\n",a,b);//有两种输入方式：1.在输入的数字间加“ ”  2.输入一个按下回车后再输入一个

    char str[30];
    scanf("%[a-f]",str);
    printf("str:%s\n",str);

}