#include<stdio.h>
#include<math.h>
int main(void)
{
    float a,b,c,s,area;
    printf("inputs:a,b,c\t");
    scanf("%F,%f,%f",&a,&b,&c);
    s = (a+b+c);
    area = (float)sqrt(s*(s-a)*(s-b)*(s-c));
    printf("area=%f\n",area);

}