#include<stdio.h>
int main(void)
{
    int a;
     printf("请输入数字\n");
     scanf("%d",&a);
    if ((float)a/2==(int)a/2)
    {
    printf("因为a除以2等于%f,所以为偶数\n",(float)a/2);
    }else{
        printf("因为a除以2等于%f,所以为奇数\n",(float)a/2);
    }
    
}