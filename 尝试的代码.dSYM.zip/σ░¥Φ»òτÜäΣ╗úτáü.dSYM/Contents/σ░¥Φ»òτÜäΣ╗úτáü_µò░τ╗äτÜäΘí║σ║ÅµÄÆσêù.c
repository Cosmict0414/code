#include<stdio.h>
int main(void){
    int a[5];   
    int i,j,temp;
    for ( i = 0; i < 5; i++)
    {
        scanf("%d",&a[i]);
    }
    
    for ( i = 0; i < 5-1; i++)
    {
        for ( j = 0; j < 5-1-i; j++)
        {
            if (a[j]>a[j+1])
            {
                temp=a[j+1];
                a[j+1]=a[j];
                a[j]=temp;
            }
            
        }
    }
    for ( i = 0; i < 5; i++)
        {
            printf("%d\n",a[i]);
        }
        return 0;
    
}